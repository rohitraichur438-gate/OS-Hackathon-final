from flask import Flask, jsonify, render_template
import json
import os
import subprocess

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MONITOR = os.path.join(BASE_DIR, "monitor")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/stats")
def stats():
    if not os.path.isfile(MONITOR):
        return jsonify({"error": "The C monitor is not compiled. Run: gcc -O2 -Wall -Wextra monitor.c -o monitor"}), 500
    try:
        result = subprocess.run(
            [MONITOR], capture_output=True, text=True, timeout=5, check=True
        )
        return jsonify(json.loads(result.stdout))
    except subprocess.TimeoutExpired:
        return jsonify({"error": "The monitoring program timed out."}), 504
    except (subprocess.CalledProcessError, json.JSONDecodeError) as exc:
        return jsonify({"error": f"Could not read Linux system information: {exc}"}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
