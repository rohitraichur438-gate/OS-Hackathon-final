# Linux System Information and Resource Monitoring Website

This project is based on the uploaded OS project abstract and presentation:
- C program on Ubuntu Linux
- `/proc` virtual file system
- Linux/POSIX interfaces
- CPU, memory, disk, uptime and process information
- Web dashboard for visual presentation

## Requirements
- Ubuntu Linux or Ubuntu in WSL
- GCC (`build-essential`)
- Python 3
- VS Code (optional)

## Run

Open the project folder in VS Code. Select **Terminal > New Terminal**, then make sure the terminal is Ubuntu/WSL.

```bash
sudo apt update
sudo apt install build-essential python3 python3-venv -y

gcc -Wall -Wextra -O2 monitor.c -o monitor

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python app.py
```

Open http://127.0.0.1:5000 in your browser.

## Notes
- The C program reads `/proc/stat`, `/proc/meminfo`, `/proc/uptime`, and `/proc` process directories.
- Disk usage is collected using `statvfs("/")`.
- Flask runs the compiled C monitor and returns its JSON output to the dashboard.
- CPU usage needs two readings; the first reading may show 0.0%.
- This is a local educational project. It does not send system data to an external server.
- Run on Linux/WSL, not native Windows PowerShell.
