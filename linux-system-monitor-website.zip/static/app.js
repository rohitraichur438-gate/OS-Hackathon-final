const $ = (id) => document.getElementById(id);
const cpuHistory = [];
const maxPoints = 30;

function setBar(id, value) {
  $(id).style.width = `${Math.max(0, Math.min(100, value))}%`;
}
function formatBytesMB(value) {
  if (!Number.isFinite(value)) return "--";
  return value >= 1024 ? `${(value / 1024).toFixed(2)} GB` : `${value.toFixed(0)} MB`;
}
function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  return `${days}d ${hours}h ${mins}m`;
}
function drawChart() {
  const canvas = $("cpuChart");
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, rect.width * ratio);
  canvas.height = Math.max(1, rect.height * ratio);
  const ctx = canvas.getContext("2d");
  ctx.scale(ratio, ratio);
  const w = rect.width, h = rect.height;
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "#292e3b";
  ctx.lineWidth = 1;
  ctx.fillStyle = "#7f899c";
  ctx.font = "9px Inter, Arial";
  [0, 25, 50, 75, 100].forEach(v => {
    const y = h - (v / 100) * (h - 12);
    ctx.beginPath(); ctx.moveTo(28, y); ctx.lineTo(w, y); ctx.stroke();
    ctx.fillText(String(v), 3, y + 3);
  });
  if (!cpuHistory.length) return;
  const points = cpuHistory.map((v, i) => ({
    x: 30 + (i / Math.max(1, maxPoints - 1)) * (w - 38),
    y: h - 6 - (v / 100) * (h - 18)
  }));
  ctx.beginPath();
  points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.strokeStyle = "#a78bfa"; ctx.lineWidth = 2; ctx.stroke();
  const last = points[points.length - 1];
  if (last) { ctx.beginPath(); ctx.arc(last.x, last.y, 3, 0, Math.PI * 2); ctx.fillStyle = "#c4b5fd"; ctx.fill(); }
}
function renderProcesses(processes) {
  const body = $("processTable");
  body.innerHTML = "";
  $("processCount").textContent = `${processes.length} PROCESSES SHOWN`;
  if (!processes.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty">No process information available.</td></tr>';
    return;
  }
  processes.forEach(proc => {
    const row = document.createElement("tr");
    const name = document.createElement("td");
    name.className = "process-name";
    name.textContent = proc.name;
    const pid = document.createElement("td"); pid.textContent = proc.pid;
    const state = document.createElement("td"); state.textContent = proc.state;
    const status = document.createElement("td");
    const pill = document.createElement("span"); pill.className = "state";
    pill.textContent = proc.state === "Z" ? "ZOMBIE" : proc.state === "S" ? "SLEEPING" : proc.state === "R" ? "RUNNING" : "ACTIVE";
    status.appendChild(pill);
    row.append(name, pid, state, status);
    body.appendChild(row);
  });
}
async function updateDashboard() {
  try {
    const response = await fetch("/api/stats", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not load system statistics.");
    $("error").hidden = true;
    $("cpuValue").textContent = data.cpu_percent.toFixed(1);
    setBar("cpuBar", data.cpu_percent);
    $("cpuFoot").textContent = `${data.cpu_percent.toFixed(1)}%`;
    cpuHistory.push(data.cpu_percent);
    if (cpuHistory.length > maxPoints) cpuHistory.shift();

    $("memValue").textContent = data.memory.percent.toFixed(1);
    setBar("memBar", data.memory.percent);
    $("memDetail").textContent = `${formatBytesMB(data.memory.used_mb)} used of ${formatBytesMB(data.memory.total_mb)}`;
    $("memDonutValue").textContent = `${data.memory.percent.toFixed(0)}%`;
    $("memoryDonut").style.background = `conic-gradient(#5ba8ff ${data.memory.percent}%, #2a3040 ${data.memory.percent}%)`;
    $("memUsed").textContent = formatBytesMB(data.memory.used_mb);
    $("memAvailable").textContent = formatBytesMB(data.memory.available_mb);

    $("diskValue").textContent = data.disk.percent.toFixed(1);
    setBar("diskBar", data.disk.percent);
    $("diskDetail").textContent = `${data.disk.used_gb.toFixed(1)} GB used of ${data.disk.total_gb.toFixed(1)} GB`;
    $("uptimeValue").textContent = formatUptime(data.uptime_seconds);
    $("hostname").textContent = data.hostname;
    $("kernel").textContent = `Kernel: ${data.kernel}`;
    renderProcesses(data.processes || []);
    drawChart();
  } catch (error) {
    $("error").textContent = error.message;
    $("error").hidden = false;
  }
}
function updateClock() {
  $("clock").textContent = new Date().toLocaleTimeString();
}
updateClock();
setInterval(updateClock, 1000);
updateDashboard();
setInterval(updateDashboard, 2000);
window.addEventListener("resize", drawChart);
