#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/statvfs.h>
#include <sys/utsname.h>
#include <unistd.h>

static unsigned long long prev_total = 0, prev_idle = 0;

static void json_string(const char *s) {
    putchar('"');
    for (; *s; s++) {
        if (*s == '"' || *s == '\\') { putchar('\\'); putchar(*s); }
        else if ((unsigned char)*s < 32) putchar(' ');
        else putchar(*s);
    }
    putchar('"');
}

static void get_cpu(double *usage) {
    FILE *f = fopen("/proc/stat", "r");
    char label[16];
    unsigned long long user=0,nice=0,system=0,idle=0,iowait=0,irq=0,softirq=0,steal=0;
    *usage = 0.0;
    if (!f) return;
    if (fscanf(f, "%15s %llu %llu %llu %llu %llu %llu %llu %llu",
               label,&user,&nice,&system,&idle,&iowait,&irq,&softirq,&steal) == 9) {
        unsigned long long idle_all = idle + iowait;
        unsigned long long total = user + nice + system + idle + iowait + irq + softirq + steal;
        if (prev_total && total > prev_total) {
            unsigned long long dt = total - prev_total;
            unsigned long long di = idle_all - prev_idle;
            *usage = 100.0 * (double)(dt - di) / (double)dt;
        }
        prev_total = total;
        prev_idle = idle_all;
    }
    fclose(f);
}

static void get_memory(unsigned long long *total, unsigned long long *available, unsigned long long *used) {
    FILE *f = fopen("/proc/meminfo", "r");
    char key[64], unit[32];
    unsigned long long value;
    *total = *available = *used = 0;
    if (!f) return;
    while (fscanf(f, "%63s %llu %31s", key, &value, unit) >= 2) {
        if (!strcmp(key, "MemTotal:")) *total = value;
        else if (!strcmp(key, "MemAvailable:")) *available = value;
        if (*total && *available) break;
    }
    fclose(f);
    if (*total >= *available) *used = *total - *available;
}

static void print_processes(void) {
    DIR *d = opendir("/proc");
    struct dirent *entry;
    int count = 0;
    printf("[");
    if (!d) { printf("]"); return; }
    while ((entry = readdir(d)) != NULL && count < 12) {
        if (!isdigit((unsigned char)entry->d_name[0])) continue;
        char path[512], name[256] = "unknown", state = '?';
        snprintf(path, sizeof(path), "/proc/%s/comm", entry->d_name);
        FILE *f = fopen(path, "r");
        if (f) { if (fgets(name, sizeof(name), f)) name[strcspn(name, "\n")] = 0; fclose(f); }
        snprintf(path, sizeof(path), "/proc/%s/stat", entry->d_name);
        f = fopen(path, "r");
        if (f) {
            char line[1024], *right;
            if (fgets(line, sizeof(line), f) && (right = strrchr(line, ')')) != NULL && right[1] == ' ')
                state = right[2];
            fclose(f);
        }
        if (count) printf(",");
        printf("{\"pid\":%s,\"name\":", entry->d_name);
        json_string(name);
        printf(",\"state\":");
        char st[2] = {state, 0};
        json_string(st);
        printf("}");
        count++;
    }
    closedir(d);
    printf("]");
}

int main(void) {
    double cpu = 0.0, uptime = 0.0;
    unsigned long long mem_total, mem_available, mem_used;
    struct statvfs disk;
    struct utsname os;
    FILE *f;
    char host[256] = "Linux";
    get_cpu(&cpu);
    get_memory(&mem_total, &mem_available, &mem_used);
    f = fopen("/proc/uptime", "r");
    if (f) { fscanf(f, "%lf", &uptime); fclose(f); }
    gethostname(host, sizeof(host)-1);
    memset(&disk, 0, sizeof(disk));
    statvfs("/", &disk);
    memset(&os, 0, sizeof(os));
    uname(&os);

    unsigned long long disk_total = (unsigned long long)disk.f_blocks * disk.f_frsize;
    unsigned long long disk_free = (unsigned long long)disk.f_bavail * disk.f_frsize;
    unsigned long long disk_used = disk_total > disk_free ? disk_total - disk_free : 0;
    double disk_percent = disk_total ? 100.0 * (double)disk_used / (double)disk_total : 0.0;
    double mem_percent = mem_total ? 100.0 * (double)mem_used / (double)mem_total : 0.0;

    printf("{\"cpu_percent\":%.1f,", cpu);
    printf("\"memory\":{\"total_mb\":%.1f,\"used_mb\":%.1f,\"available_mb\":%.1f,\"percent\":%.1f},",
           mem_total/1024.0, mem_used/1024.0, mem_available/1024.0, mem_percent);
    printf("\"disk\":{\"total_gb\":%.2f,\"used_gb\":%.2f,\"free_gb\":%.2f,\"percent\":%.1f},",
           disk_total/1073741824.0, disk_used/1073741824.0, disk_free/1073741824.0, disk_percent);
    printf("\"uptime_seconds\":%.0f,\"hostname\":", uptime);
    json_string(host);
    printf(",\"kernel\":");
    json_string(os.release);
    printf(",\"os\":");
    json_string(os.sysname);
    printf(",\"processes\":");
    print_processes();
    printf("}\n");
    return 0;
}
